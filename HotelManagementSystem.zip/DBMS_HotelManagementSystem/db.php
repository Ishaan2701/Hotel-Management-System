<?php
$con = mysqli_connect("localhost","root","","Hotel") or die(mysql_error());

?>
